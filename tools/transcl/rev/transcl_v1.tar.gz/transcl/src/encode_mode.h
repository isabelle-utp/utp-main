#ifndef ENCODE_MODE_H
#define ENCODE_MODE_H
typedef enum { relation, range_set } encode_mode_t;
#endif
