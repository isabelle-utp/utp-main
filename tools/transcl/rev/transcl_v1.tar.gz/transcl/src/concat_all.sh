#/bin/sh
cat main.c main.h argp_conf.c argp_conf.h encode_mode.h debug.c debug.h Scanner.cpp Scanner.hpp ScanException.cpp ScanException.hpp Symtab.cpp Symtab.hpp TrieNode.cpp TrieNode.hpp MapletRecorder.cpp MapletRecorder.hpp TCAlgorithm.cpp TCAlgorithm.hpp Algorithms.cpp Algorithms.hpp FloydWarshall.cpp FloydWarshall.hpp BoostAlgorithm.cpp BoostAlgorithm.hpp NullStream.cpp NullStream.hpp
