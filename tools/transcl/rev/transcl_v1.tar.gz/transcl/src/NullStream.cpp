#include "NullStream.hpp"

namespace std {
  NullStream nil;
}
