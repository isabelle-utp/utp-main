#ifndef TEST_H
#define TEST_H
/* Function prototypes */
void symtab_test();
#endif
